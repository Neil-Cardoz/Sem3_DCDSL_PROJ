
const BottomBar = () => {
    return (
        <div className='bg-gray-950 w-[100%] h-[5%] flex items-center justify-start p-8'>

        </div>
    )
}

export default BottomBar;